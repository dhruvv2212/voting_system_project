from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import hashlib
import jwt
import datetime
from blockchain import Blockchain
import random

app = Flask(__name__)
CORS(app)

SECRET_KEY = "secret123"
blockchain = Blockchain()
voted_users = set()
otp_store = {}

# ---------- OTP ----------
def generate_otp(user):
    otp = str(random.randint(100000, 999999))
    otp_store[user] = otp
    print("OTP for", user, ":", otp)
    return otp

# ---------- REGISTER ----------
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data['username']
    password = hashlib.sha256(data['password'].encode()).hexdigest()
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
    conn.commit()
    conn.close()

    return jsonify({"message": "User registered"})

# ---------- SEND OTP ----------
@app.route('/send-otp', methods=['POST'])
def send_otp():
    username = request.json['username']
    generate_otp(username)
    return jsonify({"message": "OTP sent (check terminal)"})

# ---------- VERIFY OTP ----------
@app.route('/verify-otp', methods=['POST'])
def verify_otp():
    data = request.get_json()
    username = data['username']
    otp = data['otp']

    if otp_store.get(username) == otp:
        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()

        cursor.execute("SELECT id FROM users WHERE username=?", (username,))
        user = cursor.fetchone()

        conn.close()

        if user:
            token = jwt.encode({
                "user_id": user[0],
                "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=2)
            }, SECRET_KEY, algorithm="HS256")

            return jsonify({"token": token})

    return jsonify({"message": "Invalid OTP"}), 400

# ---------- VOTE ----------
@app.route('/vote', methods=['POST'])
def vote():
    token = request.headers.get("Authorization")

    try:
        data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except:
        return jsonify({"message": "Invalid token"}), 403

    user_id = data['user_id']

    if user_id in voted_users:
        return jsonify({"message": "Already voted"}), 400

    candidate = request.json['candidate']
    voted_users.add(user_id)

    last_block = blockchain.get_last_block()
    new_block = blockchain.create_block(
        vote={"user": user_id, "candidate": candidate},
        previous_hash=last_block['hash']
    )

    return jsonify({"message": "Vote recorded", "block": new_block})

# ---------- VIEW CHAIN ----------
@app.route('/chain', methods=['GET'])
def chain():
    return jsonify(blockchain.chain)

app.run(host="0.0.0.0", port=5000, debug=True)