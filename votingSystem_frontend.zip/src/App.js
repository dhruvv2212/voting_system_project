import ChaosVote from "./ChaosVote";

function App() {
  return <ChaosVote />;
}

export default App;