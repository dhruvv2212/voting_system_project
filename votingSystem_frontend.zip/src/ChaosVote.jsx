import React, { useState } from "react";
import { registerUser, sendOTP, verifyOTP, voteCandidate } from "./api";

const ChaosVote = () => {
  const [username, setUsername] = useState("");
  const [otp, setOtp] = useState("");
  const [message, setMessage] = useState("");
  const [step, setStep] = useState(1); // 1 = Register, 2 = OTP, 3 = Verify, 4 = Vote

  // Register User
  const handleRegister = async () => {
    if (!username) return setMessage("Enter your name first!");
    try {
      const res = await registerUser({ name: username });
      setMessage(res.message || "Registered successfully!");
      setStep(2); // Move to OTP step
    } catch (err) {
      console.error(err);
      setMessage("Registration failed. Try again.");
    }
  };

  // Send OTP
  const handleSendOTP = async () => {
    try {
      const res = await sendOTP({ name: username });
      setMessage(res.message || "OTP sent!");
      setStep(3); // Move to Verify OTP step
    } catch (err) {
      console.error(err);
      setMessage("Failed to send OTP.");
    }
  };

  // Verify OTP
  const handleVerifyOTP = async () => {
    if (!otp) return setMessage("Enter OTP first!");
    try {
      const res = await verifyOTP({ name: username, otp });
      setMessage(res.message || "OTP verified!");
      setStep(4); // Move to voting step
    } catch (err) {
      console.error(err);
      setMessage("OTP verification failed.");
    }
  };

  // Vote for Candidate
  const handleVote = async (candidate) => {
    try {
      const res = await voteCandidate({ name: username, candidate });
      setMessage(res.message || "Vote recorded!");
    } catch (err) {
      console.error(err);
      setMessage("Voting failed.");
    }
  };

  return (
    <div className="chaos-vote-container">
      <h1>ChaosVote</h1>
      {message && <p className="message">{message}</p>}

      {step === 1 && (
        <div>
          <input
            type="text"
            placeholder="Enter your name"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button onClick={handleRegister}>Register</button>
        </div>
      )}

      {step === 2 && (
        <div>
          <button onClick={handleSendOTP}>Send OTP</button>
        </div>
      )}

      {step === 3 && (
        <div>
          <input
            type="text"
            placeholder="Enter OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
          />
          <button onClick={handleVerifyOTP}>Verify OTP</button>
        </div>
      )}

      {step === 4 && (
        <div>
          <button onClick={() => handleVote("Candidate A")}>Vote Candidate A</button>
          <button onClick={() => handleVote("Candidate B")}>Vote Candidate B</button>
        </div>
      )}
    </div>
  );
};

export default ChaosVote;